import { LightningElement, wire } from 'lwc';
import getAccounts from '@salesforce/apex/AccountController.getAccounts';

const columns = [
    { label: 'Name', fieldName: 'Name', type: 'text' },
    { label: 'Created Date', fieldName: 'CreatedDate', type: 'date' },
    { label: 'Owner Name', fieldName: 'Owner.Name', type: 'text' },
    {
        label: 'Active',
        fieldName: 'Active__c',
        type: 'boolean',
        typeAttributes: {
            iconName: { fieldName: 'activeIcon' },
            iconPosition: 'left',
        },
    },
];

export default class CustomLightningDataTable extends LightningElement {
    columns = columns;
    accountData = [];

    @wire(getAccounts)
    wiredAccounts({ error, data }) {
        if (data) {
            this.accountData = data.map(account => ({
                ...account,
                activeIcon: account.Active__c ? 'action:approval' : 'action:close',
            }));
        } else if (error) {
            console.error(error);
        }
    }
}